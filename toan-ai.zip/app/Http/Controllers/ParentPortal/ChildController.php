<?php

namespace App\Http\Controllers\ParentPortal;

use App\Http\Controllers\Controller;
use App\Http\Requests\ParentPortal\LinkChildRequest;
use App\Models\User;
use App\Services\AccessControlService;
use App\Services\Admin\ImpersonationService;
use App\Services\Learning\ActivityService;
use App\Services\Learning\AttendanceService;
use App\Services\Learning\RiskScoreService;
use App\Services\Learning\StreakService;
use App\Services\Learning\StudentReportService;
use App\Services\Learning\StudyScheduleService;
use App\Services\Learning\TopicSignalService;
use App\Services\OnboardingService;
use App\Services\Parenting\ChildLinkService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ChildController extends Controller
{
    public function __construct(
        private readonly ChildLinkService $links,
        private readonly StudentReportService $reports,
        private readonly AccessControlService $access,
        private readonly ActivityService $activity,
        private readonly StudyScheduleService $schedules,
        private readonly AttendanceService $attendance,
        private readonly RiskScoreService $risk,
        private readonly TopicSignalService $signals,
        private readonly StreakService $streaks,
    ) {}

    public function linkForm(): View
    {
        return view('parent.children.link');
    }

    public function link(LinkChildRequest $request): RedirectResponse
    {
        $data = $request->validated();

        $child = $this->links->linkByCode($request->user(), $data['link_code']);

        return redirect()->route('parent.children.show', $child)
            ->with('status', "Đã liên kết với {$child->name}.");
    }

    /**
     * Mở từ link / QR con chia sẻ. Route có middleware `signed` nên mã trên URL không bị sửa,
     * và link tự hết hạn. Vẫn hỏi xác nhận để phụ huynh biết mình đang liên kết với ai.
     */
    public function accept(Request $request): View|RedirectResponse
    {
        $student = $this->links->studentForCode((string) $request->query('code'));

        if (! $student) {
            return redirect()->route('parent.children.link')
                ->with('error', 'Link liên kết không còn hiệu lực — có thể con đã đổi mã. Hãy xin mã mới.');
        }

        if ($request->user()->isParentOf($student)) {
            return redirect()->route('parent.children.show', $student)
                ->with('status', "Bạn đã liên kết với {$student->name} từ trước.");
        }

        return view('parent.children.accept', [
            'student' => $student->load('studentProfile.grade'),
            'code' => $request->query('code'),
        ]);
    }

    public function show(Request $request, User $student): View
    {
        abort_unless($request->user()->isParentOf($student), 403);

        // Mục "Xem báo cáo của con lần đầu" trong danh sách Bắt đầu — người hỗ trợ đăng nhập hộ thì không tính.
        if (! $request->session()->has(ImpersonationService::SESSION_KEY)) {
            app(OnboardingService::class)->markVisited($request->user(), 'parent.children.show');
        }

        $report = $this->reports->summary($student);
        // TA-05: năng lực theo chủ đề của bài đầu vào cho phụ huynh — nạp trước (strict mode chặn lazy load).
        $placement = $report['path']?->placementTest?->loadMissing('questions.topic', 'answers');

        return view('parent.children.show', [
            'student' => $student,
            'report' => $report,
            'placementTopics' => $placement?->topicScores() ?? collect(),
            // §18 Premium: "Báo cáo nâng cao" — theo gói của CON (người được dùng gói).
            'advancedReports' => $this->access->allows($student, 'reports.advanced'),
            'tier' => $this->access->currentTier($student),
            // Thời gian học thật 7 ngày: phụ huynh thấy "online bao lâu / học thực bao lâu", không chỉ điểm.
            'activityDays' => $this->activity->lastDays($student, 7),
            'schedule' => $this->schedules->forStudent($student),
            'attendance' => $this->attendance->recent($student, 10),
            'absentStreak' => $this->attendance->consecutiveAbsences($student),
            'risk' => $risk = $this->risk->forStudent($student),
            'interventions' => $this->risk->interventions($risk),
            'helpSeeking' => $this->signals->helpSeeking($student),
            'streak' => $this->streaks->forStudent($student),
            // Mục 1–2 của trang giám sát: hôm nay có buổi nào, con đã vào chưa.
            'todaySlot' => $this->schedules->slotOn($student, today()),
            'todayAttendance' => $this->attendance->recent($student, 1)->first(fn ($a) => $a->attendance_date->isToday()),
        ]);
    }

    public function unlink(Request $request, User $student): RedirectResponse
    {
        abort_unless($request->user()->isParentOf($student), 403);

        $this->links->unlink($request->user(), $student);

        return redirect()->route('parent.dashboard')
            ->with('status', "Đã huỷ liên kết với {$student->name}.");
    }
}

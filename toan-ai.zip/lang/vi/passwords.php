<?php

return [
    'reset' => 'Mật khẩu đã được đặt lại.',
    'sent' => 'Chúng tôi đã gửi liên kết đặt lại mật khẩu qua email.',
    'throttled' => 'Vui lòng đợi một lát trước khi thử lại.',
    'token' => 'Liên kết đặt lại mật khẩu không hợp lệ hoặc đã hết hạn.',
    'user' => 'Không tìm thấy tài khoản với email này.',
];

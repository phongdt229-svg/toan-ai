<?php

use App\Http\Controllers\Api\V1\ActivityController;
use App\Http\Controllers\Api\V1\AiController;
use App\Http\Controllers\Api\V1\MomoIpnController;
use App\Http\Controllers\Api\V1\OnboardingController;
use App\Http\Controllers\Api\V1\StripeWebhookController;
use App\Http\Controllers\Api\V1\VnpayIpnController;
use App\Models\Package;
use App\Services\SubscriptionService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API v1  (prefix 'api/v1' được đặt trong bootstrap/app.php)
|--------------------------------------------------------------------------
| Các nhóm endpoint đầy đủ xem PROJECT_PLAN.md §6.
*/

Route::middleware('auth:sanctum')->get('/me', function (Request $request, SubscriptionService $subscriptions) {
    $user = $request->user()->load('roles:id,name,display_name', 'studentProfile.grade');

    return response()->json([
        'success' => true,
        'data' => [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'status' => $user->status,
            'roles' => $user->roles->pluck('name'),
            'grade' => $user->studentProfile?->grade?->name,
            'subscription' => $user->isStudent() ? [
                'tier' => $subscriptions->tier($user),
                'package' => $subscriptions->effective($user)?->package->slug,
                'ends_at' => $subscriptions->effective($user)?->ends_at?->toIso8601String(),
            ] : null,
        ],
    ]);
})->name('api.me');

// Bảng giá công khai (§18) — app mobile/PWA đọc giá từ đây, không hard-code.
Route::get('/packages', function () {
    return response()->json([
        'success' => true,
        'data' => Package::active()->ordered()->with('features')->get()->map(fn (Package $p) => [
            'slug' => $p->slug,
            'name' => $p->name,
            'tier' => $p->tier,
            'price' => (int) $p->price,
            'currency' => $p->currency,
            'duration_days' => $p->duration_days,
            'description' => $p->description,
            'highlighted' => $p->is_highlighted,
            'features' => $p->features->where('show_on_pricing', true)->values()->map(fn ($f) => [
                'key' => $f->key, 'label' => $f->label, 'enabled' => $f->isEnabled(), 'limit' => $f->limit_value,
            ]),
        ]),
    ]);
})->name('api.packages');

/*
| AI Tutor (§10). Nhóm `web` để widget trên trang gọi bằng session + CSRF, không cần token riêng.
| throttle:ai giới hạn theo phút (chống spam); quota theo ngày do AiUsageGuard kiểm.
*/
Route::middleware(['web', 'auth', 'active', 'throttle:ai'])
    ->prefix('ai')
    ->name('api.ai.')
    ->controller(AiController::class)
    ->group(function () {
        Route::post('chat', 'chat')->name('chat');
        Route::post('read-image', 'readImage')->name('read-image');
        Route::post('hint', 'hint')->name('hint');
        Route::post('explain', 'explain')->name('explain');
        Route::post('check-answer', 'checkAnswer')->name('check-answer');
        Route::post('similar-exercise', 'similarExercise')->name('similar-exercise');
        Route::post('analyze-mistake', 'analyzeMistake')->name('analyze-mistake');

        Route::get('usage', 'usage')->name('usage')->withoutMiddleware('throttle:ai');
        Route::get('conversations', 'conversations')->name('conversations')->withoutMiddleware('throttle:ai');
        Route::get('conversations/{id}', 'conversation')->whereNumber('id')->name('conversation')->withoutMiddleware('throttle:ai');
    });

/*
| IPN MoMo (§8) — server-to-server, không auth, không CSRF (loại trừ trong bootstrap/app.php).
| Căn cứ duy nhất là chữ ký; luôn trả 204.
*/
Route::post('payment/momo/ipn', MomoIpnController::class)
    ->middleware('throttle:60,1')
    ->name('api.payment.momo.ipn');

/*
| Thời gian học thật — trình duyệt của học sinh gửi heartbeat mỗi 30 giây (session + CSRF như AI Tutor).
| 6 lượt/phút đủ cho 2 tab; số giây được cộng do server tính nên gửi dồn cũng không lợi gì.
*/
Route::post('activity', ActivityController::class)
    ->middleware(['web', 'auth', 'active', 'throttle:6,1'])
    ->name('api.activity');

// Tiến độ hướng dẫn người mới (OB-03) — session + CSRF như heartbeat học tập.
Route::post('onboarding', OnboardingController::class)
    ->middleware(['web', 'auth', 'active', 'throttle:30,1'])
    ->name('api.onboarding');

// Webhook Stripe (ST-02): chữ ký tính trên thân request thô — loại trừ CSRF trong bootstrap/app.php.
Route::post('payment/stripe/webhook', StripeWebhookController::class)
    ->middleware('throttle:120,1')
    ->name('api.payment.stripe.webhook');

// IPN VNPAY là GET nên không đụng CSRF; URL này phải khai trong trang quản trị merchant của VNPAY.
Route::get('payment/vnpay/ipn', VnpayIpnController::class)
    ->middleware('throttle:60,1')
    ->name('api.payment.vnpay.ipn');

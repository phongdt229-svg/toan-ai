<?php

use Illuminate\Support\Facades\Schedule;

/*
|--------------------------------------------------------------------------
| Lịch chạy định kỳ
|--------------------------------------------------------------------------
| Local chạy bằng `php artisan schedule:work`.
| Production cần cron: * * * * * php artisan schedule:run
*/

// Lượt làm đề quá giờ mà không nộp → tự nộp (§16, PROJECT_PLAN Phase 4).
Schedule::command('exams:finalize-expired')
    ->everyMinute()
    ->withoutOverlapping();

// Dọn trạng thái gói: quá hạn → expired, chờ thanh toán bỏ dở > 24h → cancelled (§19).
// Quyền truy cập vốn dựa vào ends_at nên job chạy trễ cũng không cho dùng lố hạn.
// 18:00 — sau giờ học, còn kịp làm buổi tối.
Schedule::command('assignments:remind-due')
    ->dailyAt('18:00')
    ->withoutOverlapping();

// Điểm danh theo lịch học: mỗi phút, vì "quá 15 phút chưa vào" phải báo phụ huynh khi còn kịp nhắc con.
Schedule::command('attendance:tick')
    ->everyMinute()
    ->withoutOverlapping();

// 21:30 — sau buổi học tối; chỉ phụ huynh đã bật trong Cài đặt (mặc định tắt).
Schedule::command('reports:daily-parents')
    ->dailyAt('21:30')
    ->withoutOverlapping();

// 07:00 — trước giờ đi học/đi làm: phụ huynh biết hôm nay con có buổi học nào để nhắc con đúng giờ.
Schedule::command('parents:remind-schedule')
    ->dailyAt('07:00')
    ->withoutOverlapping();

// 19:00 — sau bữa tối, học sinh chưa học hôm nay (hoặc có chủ đề sắp quên) được nhắc một lần.
Schedule::command('students:remind-study')
    ->dailyAt('19:00')
    ->withoutOverlapping();

// 08:00 chu khong gop vao subscriptions:expire luc 00:05 - khong ai muon nhan email gia han luc nua dem.
Schedule::command('subscriptions:remind-expiring')
    ->dailyAt('08:00')
    ->withoutOverlapping();

Schedule::command('subscriptions:expire')
    ->dailyAt('00:05')
    ->withoutOverlapping();

// Đơn MoMo quá hạn chưa trả: hỏi lại MoMo rồi mới huỷ (không huỷ nhầm đơn IPN bị lạc).
Schedule::command('payments:expire-pending')
    ->everyFiveMinutes()
    ->withoutOverlapping();

// Báo cáo tuần cho phụ huynh — tối Chủ nhật, lúc phụ huynh thường ngồi xem lại tuần học của con (§14).
Schedule::command('reports:weekly-parents')
    ->weeklyOn(0, '19:00')
    ->withoutOverlapping();

// Sao lưu DB lúc ít người học nhất; giữ BACKUP_KEEP_DAYS ngày. Chỉ chạy trên máy chủ thật.
Schedule::command('backup:database')
    ->dailyAt('02:00')
    ->environments(['production', 'staging'])
    ->withoutOverlapping()
    ->onOneServer();

// Dọn job lỗi cũ và token Sanctum hết hạn để bảng không phình.
Schedule::command('queue:prune-failed --hours=720')->weekly();
Schedule::command('sanctum:prune-expired --hours=168')->daily();

// Tài khoản đã yêu cầu xoá quá 30 ngày → ẩn danh vĩnh viễn (cam kết ở Chính sách bảo mật).
Schedule::command('accounts:purge')
    ->dailyAt('03:00')
    ->withoutOverlapping();

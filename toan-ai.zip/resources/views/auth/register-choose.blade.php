@extends('layouts.guest')

@section('title', 'Đăng ký — Math AI')
@section('meta_description', 'Tạo tài khoản Math AI miễn phí cho học sinh'.(\App\Support\RolePortal::enabled('teacher') ? ', giáo viên' : '').(\App\Support\RolePortal::enabled('parent') ? ', phụ huynh' : '').' — bắt đầu học Toán lớp 1–12 ngay.')

@section('content')
    <h1 class="h4 fw-bold text-center mb-1">Bạn là ai?</h1>
    <p class="text-secondary text-center small mb-4">Chọn loại tài khoản để tiếp tục.</p>

    <div class="d-grid gap-3">
        @foreach (array_filter([
            ['register.student', 'bi-mortarboard', 'Học sinh', 'Học lý thuyết, luyện tập và hỏi AI Tutor.'],
            \App\Support\RolePortal::enabled('teacher') ? ['register.teacher', 'bi-person-video3', 'Giáo viên', 'Soạn bài, quản lý lớp và giao bài tập.'] : null,
            \App\Support\RolePortal::enabled('parent') ? ['register.parent', 'bi-people', 'Phụ huynh', 'Theo dõi việc học của con.'] : null,
        ]) as [$route, $icon, $label, $desc])
            <a href="{{ route($route) }}" class="card border text-decoration-none text-body">
                <div class="card-body d-flex align-items-center gap-3 p-3">
                    <div class="feature-card__icon flex-shrink-0 mb-0"><i class="bi {{ $icon }}"></i></div>
                    <div class="flex-grow-1">
                        <div class="fw-semibold">{{ $label }}</div>
                        <div class="text-secondary small">{{ $desc }}</div>
                    </div>
                    {{-- span chứ không phải <a>/<button>: cả thẻ đã là link, lồng phần tử bấm được vào link là HTML sai. --}}
                    <span class="btn btn-primary btn-sm flex-shrink-0">Đăng ký</span>
                </div>
            </a>
        @endforeach
    </div>

    <p class="text-center text-secondary small mt-4 mb-0">
        Đã có tài khoản? <a href="{{ route('login') }}">Đăng nhập</a>
    </p>
@endsection

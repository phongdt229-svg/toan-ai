<?php

/*
|--------------------------------------------------------------------------
| Menu theo role
|--------------------------------------------------------------------------
| `bottom` = true → hiện ở bottom nav trên mobile (§3, tối đa 4 mục).
| `route` = null  → chưa làm ở phase hiện tại, render dạng disabled.
| `active` = danh sách mẫu tên route (vd 'student.qa.*') cùng làm sáng mục này, mặc định chỉ `route`.
| `tour` = giá trị data-tour cho tour hướng dẫn người mới (config/onboarding.php).
*/

return [

    'student' => [
        ['label' => 'Trang chủ', 'icon' => 'bi-house', 'route' => 'student.dashboard', 'bottom' => true],
        ['label' => 'Học', 'icon' => 'bi-journal-text', 'route' => 'student.learn.index', 'bottom' => true, 'tour' => 'nav-learn'],
        ['label' => 'Bài tập', 'icon' => 'bi-pencil-square', 'route' => 'student.practice.index', 'bottom' => true],
        // Hỏi đáp theo chủ đề + hỏi AI gom một mục (yêu cầu 31/10); hai trang có thanh tab chuyển qua lại.
        ['label' => 'Hỏi đáp', 'icon' => 'bi-chat-dots', 'route' => 'student.qa.index', 'active' => ['student.qa.*', 'student.ai.*'], 'bottom' => true],
        ['label' => 'Đề kiểm tra', 'icon' => 'bi-clipboard-check', 'route' => 'student.exams.index', 'bottom' => false],
        ['label' => 'Bài được giao', 'icon' => 'bi-list-check', 'route' => 'student.assignments.index', 'bottom' => false],
        ['label' => 'Phụ huynh', 'icon' => 'bi-house-heart', 'route' => 'student.parents.index', 'bottom' => false, 'portal' => 'parent'],
        ['label' => 'Lộ trình', 'icon' => 'bi-signpost-split', 'route' => 'student.path.show', 'bottom' => false, 'tour' => 'nav-path'],
        ['label' => 'Hình học phẳng', 'icon' => 'bi-triangle', 'route' => 'student.plane-geometry.index', 'bottom' => false],
        ['label' => 'Hình học không gian', 'icon' => 'bi-box', 'route' => 'student.solid-geometry.index', 'bottom' => false],
        ['label' => 'Lịch học', 'icon' => 'bi-calendar-week', 'route' => 'student.schedule.edit', 'bottom' => false, 'tour' => 'nav-schedule'],
        ['label' => 'Gói của tôi', 'icon' => 'bi-gem', 'route' => 'student.subscription.index', 'bottom' => false],
        ['label' => 'Cài đặt', 'icon' => 'bi-gear', 'route' => 'student.settings', 'bottom' => false],
    ],

    'teacher' => [
        ['label' => 'Dashboard', 'icon' => 'bi-speedometer2', 'route' => 'teacher.dashboard', 'bottom' => true],
        ['label' => 'Lớp học', 'icon' => 'bi-people', 'route' => 'teacher.classes.index', 'bottom' => true, 'tour' => 'nav-classes'],
        ['label' => 'Bài học', 'icon' => 'bi-journal-text', 'route' => 'teacher.lessons.index', 'bottom' => true],
        ['label' => 'Câu hỏi', 'icon' => 'bi-question-circle', 'route' => 'teacher.questions.index', 'bottom' => true, 'tour' => 'nav-questions'],
        ['label' => 'Đề kiểm tra', 'icon' => 'bi-clipboard-check', 'route' => 'teacher.exams.index', 'bottom' => false],
        ['label' => 'Giao bài', 'icon' => 'bi-send-check', 'route' => 'teacher.assignments.index', 'bottom' => false, 'tour' => 'nav-assign'],
        ['label' => 'Học sinh', 'icon' => 'bi-mortarboard', 'route' => 'teacher.students.index', 'bottom' => false, 'tour' => 'nav-students'],
        ['label' => 'AI soạn bài', 'icon' => 'bi-robot', 'route' => 'teacher.ai.index', 'bottom' => false, 'tour' => 'nav-teacher-ai'],
        // Hỏi đáp dùng chung một URL cho mọi portal (route auth, không riêng học sinh) — giáo viên
        // trả lời và kiểm duyệt được nhưng không có lối vào từ menu của họ thì không ai biết mà bấm.
        ['label' => 'Hỏi đáp', 'icon' => 'bi-chat-dots', 'route' => 'student.qa.index', 'bottom' => false],
        ['label' => 'Báo cáo', 'icon' => 'bi-bar-chart', 'route' => 'teacher.reports.index', 'bottom' => false],
        ['label' => 'Tìm kiếm', 'icon' => 'bi-search', 'route' => 'teacher.search', 'bottom' => false],
        ['label' => 'Cài đặt', 'icon' => 'bi-gear', 'route' => 'teacher.settings', 'bottom' => false],
    ],

    'parent' => [
        ['label' => 'Con của tôi', 'icon' => 'bi-house-heart', 'route' => 'parent.dashboard', 'bottom' => true],
        ['label' => 'Liên kết con', 'icon' => 'bi-person-plus', 'route' => 'parent.children.link', 'bottom' => true, 'tour' => 'nav-link-child'],
        ['label' => 'Gói học', 'icon' => 'bi-gem', 'route' => 'parent.subscriptions.index', 'bottom' => true],
        ['label' => 'Cài đặt', 'icon' => 'bi-gear', 'route' => 'parent.settings', 'bottom' => true, 'tour' => 'nav-parent-settings'],
    ],

    'admin' => [
        ['label' => 'Dashboard', 'icon' => 'bi-speedometer2', 'route' => 'admin.dashboard', 'bottom' => true],
        ['label' => 'Duyệt giáo viên', 'icon' => 'bi-person-check', 'route' => 'admin.teachers.pending', 'bottom' => true],
        ['label' => 'Người dùng', 'icon' => 'bi-people', 'route' => 'admin.users.index', 'bottom' => true],
        ['label' => 'Chương trình', 'icon' => 'bi-diagram-3', 'route' => 'admin.curriculum.index', 'bottom' => true],
        ['label' => 'Bài viết', 'icon' => 'bi-newspaper', 'route' => 'admin.blog.index', 'bottom' => false],
        ['label' => 'Danh mục bài viết', 'icon' => 'bi-tags', 'route' => 'admin.blog-categories.index', 'bottom' => false],
        ['label' => 'Gói học', 'icon' => 'bi-gem', 'route' => 'admin.packages.index', 'bottom' => false],
        ['label' => 'Mã giảm giá', 'icon' => 'bi-ticket-perforated', 'route' => 'admin.vouchers.index', 'bottom' => false],
        ['label' => 'Đăng ký gói', 'icon' => 'bi-person-vcard', 'route' => 'admin.subscriptions.index', 'bottom' => false],
        ['label' => 'Giao dịch', 'icon' => 'bi-credit-card', 'route' => 'admin.payments.index', 'bottom' => false],
        ['label' => 'Google Analytics', 'icon' => 'bi-graph-up-arrow', 'route' => 'admin.analytics.index', 'bottom' => false],
        ['label' => 'AI usage', 'icon' => 'bi-robot', 'route' => 'admin.ai-usage.index', 'bottom' => false],
        ['label' => 'Hỗ trợ', 'icon' => 'bi-life-preserver', 'route' => 'admin.support.index', 'bottom' => false],
        ['label' => 'Audit log', 'icon' => 'bi-shield-check', 'route' => 'admin.audit-logs.index', 'bottom' => false],
        ['label' => 'Bảo trì', 'icon' => 'bi-cone-striped', 'route' => 'admin.maintenance.edit', 'bottom' => false],
        ['label' => 'SEO', 'icon' => 'bi-search', 'route' => 'admin.seo.index', 'bottom' => false],
        ['label' => 'Chính sách', 'icon' => 'bi-file-earmark-text', 'route' => 'admin.legal.index', 'active' => ['admin.legal.*'], 'bottom' => false],
        // Cùng lý do ở nav teacher: admin kiểm duyệt được (Gate::before) nhưng không có lối vào riêng.
        ['label' => 'Hỏi đáp', 'icon' => 'bi-chat-dots', 'route' => 'student.qa.index', 'bottom' => false],
        ['label' => 'Cài đặt', 'icon' => 'bi-gear', 'route' => 'admin.settings', 'bottom' => false],
    ],

];

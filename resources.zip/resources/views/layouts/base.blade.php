<!DOCTYPE html>
<html lang="vi" class="@yield('html_class')">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    @php
        // Admin sửa được ở Quản trị → SEO (App\Models\SeoPage) mà không cần đụng code — ưu tiên
        // override đó, rơi về @section(...) của từng trang, rồi giá trị mặc định của site.
        $seoRouteName = optional(request()->route())->getName();
        $seoPages = app(\App\Services\Content\SeoPageService::class);

        $defaultMetaDescription = 'Nền tảng học Toán trực tuyến lớp 1–12 cùng AI Tutor.';
        $metaDescription = $seoPages->descriptionFor($seoRouteName)
            ?: trim($__env->yieldContent('meta_description', $defaultMetaDescription))
            ?: $defaultMetaDescription;

        $pageTitle = $seoPages->titleFor($seoRouteName)
            ?: trim($__env->yieldContent('title', config('site.brand')))
            ?: config('site.brand');

        $metaKeywords = $seoPages->keywordsFor($seoRouteName);
    @endphp
    <meta name="description" content="{{ $metaDescription }}">
    {{-- E-E-A-T: trang nào có tác giả riêng (bài tin tức) thì khai @section('author'). --}}
    <meta name="author" content="@yield('author', \App\Support\PageAuthor::name())">
    @if ($metaKeywords)
        <meta name="keywords" content="{{ $metaKeywords }}">
    @endif

    @php
        // Chỉ nạp công cụ đo lường khi người dùng đã bấm "Đồng ý". Chặn ngay từ server:
        // nạp script rồi mới gọi API tắt là muộn, cookie của Google đã đặt xong từ trước đó.
        $analyticsAllowed = request()->cookie(\App\Http\Controllers\Web\CookieConsentController::COOKIE)
            === \App\Http\Controllers\Web\CookieConsentController::ACCEPTED;
    @endphp

    {{-- Google Tag Manager — Google yêu cầu đặt càng cao trong <head> càng tốt. Trống ở local/test. --}}
    @if ($analyticsAllowed && config('site.google_tag_manager_id'))
        <script>
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer',@json(config('site.google_tag_manager_id')));
        </script>
    @endif

    <title>{{ $pageTitle }}</title>

    {{--
        Thẻ chia sẻ mạng xã hội (Zalo, Facebook, Messenger). Trang nào muốn preview riêng thì
        khai báo @section('og_title') / @section('og_description') / @section('og_image');
        không khai báo thì lấy lại title + meta description của chính trang đó.
        Ảnh mặc định: public/og-cover.png (1200×630) — đổi ảnh thì thay đúng file này.
    --}}
    @php
        $ogTitle = trim($__env->yieldContent('og_title')) ?: $pageTitle;
        $ogDescription = trim($__env->yieldContent('og_description')) ?: $metaDescription;
        $ogImage = trim($__env->yieldContent('og_image')) ?: asset('og-cover.png');

        // Canonical chuẩn hoá thay vì url()->current(): www.<miền> và /index.php đều trả 200 cùng nội dung,
        // mà canonical lại tự trỏ về chính nó → Google thấy cả site bị nhân đôi. Lấy miền theo request
        // (không theo APP_URL — sai APP_URL thì cả site canonical sang miền khác, còn tệ hơn).
        // Trang phân trang giữ ?page=N: trỏ hết về trang 1 thì bài cũ ở trang sau dễ rơi khỏi chỉ mục.
        $canonical = preg_replace('#^(https?://)www\.#', '$1', rtrim(str_replace('/index.php', '', url('/')), '/'));
        $canonical .= request()->path() === '/' ? '' : '/'.request()->path();
        if (($page = (int) request()->query('page')) > 1) {
            $canonical .= '?page='.$page;
        }
    @endphp

    <meta name="robots" content="@yield('robots', 'index,follow')">
    <link rel="canonical" href="{{ $canonical }}">

    <meta property="og:site_name" content="{{ config('site.brand') }}">
    <meta property="og:locale" content="vi_VN">
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:url" content="{{ $canonical }}">
    <meta property="og:title" content="{{ $ogTitle }}">
    <meta property="og:description" content="{{ $ogDescription }}">
    <meta property="og:image" content="{{ $ogImage }}">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="{{ $ogTitle }}">
    <meta name="twitter:description" content="{{ $ogDescription }}">
    <meta name="twitter:image" content="{{ $ogImage }}">

    {{-- PWA --}}
    <link rel="manifest" href="/manifest.webmanifest">
    <meta name="theme-color" content="#2563eb">
    <link rel="icon" href="/favicon.ico" sizes="48x48">
    <link rel="icon" type="image/png" href="/icons/icon-192.png" sizes="192x192">
    <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="Math AI">

    @if (config('site.google_site_verification'))
        <meta name="google-site-verification" content="{{ config('site.google_site_verification') }}">
    @endif

    {{--
        JSON-LD sitewide (schema.org) — chỉ đặt trên trang được lập chỉ mục (@yield('robots') không
        chứa "noindex"); đặt cả ở trang sau đăng nhập là vô nghĩa, Google không đọc trang đó.
        `name` lấy config('site.brand') (tên hiển thị công khai, vd "Math AI"), `legalName` lấy
        config('site.company') (tên pháp nhân, vd "Math AI") — hai trường khác nhau thật trong
        config/site.php, không gộp làm một cho "gọn".
    --}}
    @php $robotsMeta = trim($__env->yieldContent('robots', 'index,follow')); @endphp
    @unless (str_contains($robotsMeta, 'noindex'))
        <script type="application/ld+json">
            {!! json_encode([
                '@@context' => 'https://schema.org',
                '@graph' => [
                    array_filter([
                        '@type' => 'EducationalOrganization',
                        '@id' => url('/').'#organization',
                        'name' => config('site.brand'),
                        // GEO: tên phụ + sameAs để công cụ AI nối mọi cách gọi và các trang mạng xã hội
                        // về CÙNG một thực thể. sameAs chỉ nhận link thật (SocialLink lọc link mẫu).
                        'alternateName' => \App\Services\Content\LlmsTxtService::alternateNames() ?: null,
                        'legalName' => config('site.company'),
                        'description' => 'Nền tảng học Toán trực tuyến lớp '.config('learning.grade_min').'–'.config('learning.grade_max')
                            .' bám sát chương trình giáo dục phổ thông 2018 của Việt Nam, có AI Tutor gợi ý từng bước thay vì đưa sẵn đáp án.',
                        'url' => url('/'),
                        'logo' => asset('icons/icon-512.png'),
                        'email' => config('site.email') ?: null,
                        // Local SEO: NAP lấy chung một nguồn với footer (SiteContact) — xem lý do ở class đó.
                        'telephone' => \App\Support\SiteContact::telephone(),
                        'address' => \App\Support\SiteContact::postalAddress(),
                        'contactPoint' => \App\Support\SiteContact::contactPoint(),
                        'hasMap' => \App\Support\SiteContact::mapUrl(),
                        'areaServed' => ['@type' => 'Country', 'name' => 'Việt Nam', 'identifier' => 'VN'],
                        'knowsLanguage' => 'vi',
                        'sameAs' => collect(config('site.social', []))
                            ->filter(fn ($link) => \App\Support\SocialLink::isUsable($link))->values()->all() ?: null,
                    ]),
                    array_filter([
                        '@type' => 'WebSite',
                        '@id' => url('/').'#website',
                        'name' => config('site.brand'),
                        'alternateName' => \App\Services\Content\LlmsTxtService::alternateNames() ?: null,
                        'url' => url('/'),
                        'inLanguage' => 'vi',
                    ]),
                ],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!}
        </script>
    @endunless

    @vite(['resources/scss/app.scss', 'resources/js/app.js'])

    {{--
        Font Be Vietnam Pro nạp SAU khi trang đã hiện chữ: 9 file ~150 KB mà tải cùng lúc với CSS chính thì
        trên 4G chữ hiện chậm ~0,9s (PageSpeed mobile 92 → 98 khi tách ra). Phải chờ first-contentful-paint chứ
        không chờ load — mạng nhanh thì load bắn TRƯỚC lần vẽ đầu, font lại chen vào đúng đoạn cần tránh.
        Lượt xem sau font đã trong cache 1 năm → gắn ngay để khỏi thấy chữ đổi font ở mỗi trang.
        Không có JS thì <noscript> lo.
    --}}
    @php $webfonts = Vite::asset('resources/scss/webfonts.scss'); @endphp
    <script>
        (function (href) {
            var key = 'webfonts-cached';
            function add() {
                var link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = href;
                document.head.appendChild(link);
            }
            try { if (localStorage.getItem(key)) { add(); return; } } catch (e) {}

            var done = false;
            function later() {
                if (done) return;
                done = true;
                add();
                try { localStorage.setItem(key, '1'); } catch (e) {}
            }
            try {
                new PerformanceObserver(function (list) {
                    if (list.getEntriesByName('first-contentful-paint').length) setTimeout(later, 0);
                }).observe({ type: 'paint', buffered: true });
            } catch (e) {}
            // Trình duyệt không có Paint Timing (hoặc trang không vẽ chữ nào) thì vẫn có font.
            addEventListener('load', function () { setTimeout(later, 1500); });
        })(@json($webfonts));
    </script>
    <noscript><link rel="stylesheet" href="{{ $webfonts }}"></noscript>
    @stack('head')

    {{--
        Google Analytics 4. Trống ở local/test (xem config/site.php) nên dev không làm bẩn số liệu.
        Đặt CUỐI <head>: script `async` nhưng vẫn là một lượt tải thêm, không để nó chen trước CSS.
        CSP hiện không khai script-src nên không phải mở thêm nguồn — xem SecurityHeaders.
    --}}
    @if ($analyticsAllowed && config('site.google_analytics_id'))
        @php $gaId = config('site.google_analytics_id'); @endphp
        <script async src="https://www.googletagmanager.com/gtag/js?id={{ $gaId }}"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', @json($gaId));
        </script>
    @endif
</head>
<body>
    {{-- GTM bản dự phòng cho trình duyệt tắt JS — phải nằm ngay sau <body>. --}}
    @if ($analyticsAllowed && config('site.google_tag_manager_id'))
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id={{ config('site.google_tag_manager_id') }}"
                    height="0" width="0" style="display:none;visibility:hidden" title="Google Tag Manager"></iframe>
        </noscript>
    @endif

    {{--
        Đang bảo trì mà vẫn xem được trang này nghĩa là trình duyệt đang giữ cookie bỏ qua.
        Không báo rõ thì người vừa bật bảo trì dễ tưởng là bật hụt, rồi bật thêm lần nữa.
        Style viết thẳng vào thẻ: dải này hiếm khi xuất hiện, không đáng thêm vào bundle CSS.
    --}}
    @if (app()->isDownForMaintenance())
        {{-- Nổi ở góc dưới bên trái: header trang chủ là sticky, sidebar và bottom nav thì fixed —
             một dải ngang ở đỉnh sẽ đè lên chúng. Góc này trống ở cả 4 portal lẫn trang công khai. --}}
        <style>
            .maintenance-flag {
                position: fixed; left: 12px; bottom: 12px; z-index: 2000; max-width: 300px;
                background: #b45309; color: #fff; border-radius: 10px; padding: .6rem .8rem;
                font-size: .78rem; line-height: 1.45; box-shadow: 0 6px 20px rgba(0, 0, 0, .25);
            }
            .maintenance-flag a { color: #fff; font-weight: 600; }
            @media (max-width: 991.98px) { .maintenance-flag { bottom: 76px; } }
        </style>
        <div class="maintenance-flag">
            <strong>Site đang bảo trì.</strong>
            Mọi người khác — kể cả ở trang chủ — đang thấy trang "Hệ thống đang được nâng cấp".
            Bạn vào được là nhờ quyền bỏ qua.
            @auth
                @if (auth()->user()->isAdmin())
                    <a href="{{ route('admin.maintenance.edit') }}">Tắt bảo trì</a>
                @endif
            @endauth
        </div>
    @endif

    @yield('body')

    @include('components.cookie-consent')

    @stack('widgets')
    @stack('scripts')
</body>
</html>

@extends('layouts.app', ['portal' => 'student'])

@section('title', 'Cài đặt — Math AI')
@section('page_title', 'Cài đặt')

@section('content')
    <h2 class="h5 fw-bold mb-3">Cài đặt tài khoản</h2>

    @include('partials.profile-form', ['profileRoute' => route('student.settings.profile')])
    @include('student.partials.personalization-form', ['profile' => $user->studentProfile])
    @include('partials.email-form')
    @include('partials.notification-preferences-form')
    @include('partials.password-form', ['passwordRoute' => route('student.settings.password')])
    @include('partials.data-export')
    @include('partials.danger-zone')
@endsection

<section class="hero">
    <span class="hero__blob hero__blob--1" aria-hidden="true"></span>
    <span class="hero__blob hero__blob--2" aria-hidden="true"></span>

    <div class="container hero__content">
        <div class="row align-items-center g-4 g-lg-5">
            <div class="col-12 col-lg-6">
                <span class="section__eyebrow">
                    <i class="bi bi-stars"></i>Lớp {{ config('learning.grade_min') }} → Lớp {{ config('learning.grade_max') }} · Bám sát chương trình
                </span>

                <h1 class="hero__title mb-3">
                    Học Toán online<br class="d-none d-sm-block">
                    thông minh cùng <span class="hero__gradient-text">AI</span>
                </h1>

                <p class="hero__lead mb-4">
                    Lý thuyết dễ hiểu, ví dụ minh họa, luyện tập có chấm điểm và một AI Tutor
                    không đưa sẵn đáp án — mà giúp con <strong>hiểu vì sao</strong>.
                </p>

                <div class="d-grid d-sm-flex gap-2 mb-4">
                    <a href="{{ route('register') }}" class="btn btn-accent btn-lg btn-touch">
                        <i class="bi bi-rocket-takeoff"></i>Bắt đầu học miễn phí
                    </a>
                    <a href="#chuong-trinh" class="btn btn-outline-primary btn-lg btn-touch">Xem chương trình</a>

                    {{-- Ẩn sẵn; install-app.js chỉ hiện khi trình duyệt báo là cài được.
                         iPhone không bắn sự kiện đó nên nút không hiện — bài hướng dẫn lo phần đó. --}}
                    <button type="button" data-install-app hidden
                            class="btn btn-outline-secondary btn-lg btn-touch">
                        <i class="bi bi-download me-1"></i>Cài ứng dụng
                    </button>
                </div>

                {{-- Chỉ nêu điều đúng với sản phẩm, không bịa số người dùng. --}}
                <div class="hero__stats">
                    @foreach ([
                        [config('learning.grade_max') - config('learning.grade_min') + 1, 'lớp từ '.\App\Models\Grade::rangeLabel()],
                        ['6', 'dạng câu hỏi'],
                        ['5', 'chế độ AI Tutor'],
                        ['0₫', 'để bắt đầu'],
                    ] as [$value, $label])
                        <div class="hero__stat">
                            <strong>{{ $value }}</strong>
                            <span>{{ $label }}</span>
                        </div>
                    @endforeach
                </div>

                <div class="d-flex flex-wrap gap-3 mt-3 text-secondary small">
                    <span><i class="bi bi-check-circle-fill text-success me-1"></i>Không cần thẻ tín dụng</span>
                    <a href="#cai-dat-ung-dung" class="text-secondary text-decoration-none"><i class="bi bi-phone me-1"></i>Cài được như ứng dụng — xem bên dưới</a>
                </div>
            </div>

            <div class="col-12 col-lg-6">
                <div class="device">
                    {{-- Hai thẻ này phải nói đúng thứ sản phẩm có thật: chấm tự động (GradingService)
                         và lộ trình riêng (LearningPathService). Trước đây là "+10 điểm" và "7 ngày liên tiếp"
                         trong khi hệ thống không hề có điểm thưởng hay chuỗi ngày học. --}}
                    <div class="device__chip device__chip--grade">
                        <i class="bi bi-patch-check-fill text-success"></i>Chấm ngay
                    </div>
                    <div class="device__chip device__chip--path">
                        <i class="bi bi-signpost-split-fill text-primary"></i>Lộ trình riêng
                    </div>

                    {{-- Công thức minh hoạ viết sẵn bằng MathML (trình duyệt tự vẽ), không dùng data-math:
                         trang chủ khỏi tải KaTeX ~260 KB chỉ để vẽ một phân số — điểm PageSpeed mobile. --}}
                    <div class="device__screen">
                        <div class="device__notch" aria-hidden="true"></div>

                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="badge text-bg-light border">Lớp 6 · Phân số</span>
                            <span class="small text-secondary"><i class="bi bi-clock me-1"></i>8 phút</span>
                        </div>

                        <div class="fw-bold mb-2">Cộng hai phân số khác mẫu</div>
                        <p class="small text-secondary mb-2">Quy đồng rồi cộng tử số:</p>
                        <p class="mb-3 math-static">
                            <math display="block">
                                <mfrac><mn>1</mn><mn>2</mn></mfrac><mo>+</mo><mfrac><mn>1</mn><mn>3</mn></mfrac>
                                <mo>=</mo>
                                <mfrac><mn>3</mn><mn>6</mn></mfrac><mo>+</mo><mfrac><mn>2</mn><mn>6</mn></mfrac>
                                <mo>=</mo>
                                <mfrac><mn>5</mn><mn>6</mn></mfrac>
                            </math>
                        </p>

                        <div class="progress mb-3" style="height:6px" role="progressbar"
                             aria-label="Tiến độ bài học" aria-valuenow="72" aria-valuemin="0" aria-valuemax="100">
                            <div class="progress-bar" style="width:72%"></div>
                        </div>

                        <div class="border-top pt-3 d-flex gap-2 align-items-start">
                            <span class="feature-card__icon mb-0" style="width:36px;height:36px;font-size:1.125rem">
                                <i class="bi bi-robot"></i>
                            </span>
                            <div class="small">
                                <div class="fw-semibold">AI Tutor</div>
                                <div class="text-secondary">
                                    Em cộng thẳng tử với tử, mẫu với mẫu đúng không? Thử nghĩ xem:
                                    hai phần bánh chia khác nhau thì cộng trực tiếp được chưa?
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
